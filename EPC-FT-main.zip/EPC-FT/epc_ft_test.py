import argparse
import os
import torch
import imageio
import numpy as np
import torch.nn.functional as F
from dataset import TestDataset
from model_factory import build_model


parser = argparse.ArgumentParser()
parser.add_argument("--model", type=str, default="sam3", choices=["sam3", "sam2"],
                help="EPC-FT backbone: sam3 or sam2")
parser.add_argument("--checkpoint", type=str, required=True,
                help="path to the trained model checkpoint")
parser.add_argument("--backbone_checkpoint", type=str, default=None,
                help="optional backbone pretrained checkpoint for model construction")
parser.add_argument("--sam2_type", type=str, default="l",
                help="sam2 backbone type: t/s/b+/l")
parser.add_argument("--sam2_cfg", type=str, default=None,
                help="optional direct sam2 config name")
parser.add_argument("--test_image_path", type=str, required=True,
                    help="path to the image files for testing")
parser.add_argument("--test_gt_path", type=str, required=True,
                    help="path to the mask files for testing")
parser.add_argument("--save_path", type=str, required=True,
                    help="path to save the predicted masks")
parser.add_argument("--img_size", type=int, default=504,
                help="test image size")
args = parser.parse_args()


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
test_loader = TestDataset(args.test_image_path, args.test_gt_path, args.img_size)
model = build_model(
    model_name=args.model,
    checkpoint_path=args.backbone_checkpoint,
    img_size=args.img_size,
    sam2_type=args.sam2_type,
    sam2_cfg=args.sam2_cfg,
).to(device)
model.load_state_dict(torch.load(args.checkpoint, map_location=device), strict=True)
model.eval()
os.makedirs(args.save_path, exist_ok=True)
for i in range(test_loader.size):
    with torch.no_grad():
        image, gt, name = test_loader.load_data()
        gt = np.asarray(gt, np.float32)
        image = image.to(device)
        res = model(image)
        res = F.interpolate(res, size=gt.shape, mode='bilinear', align_corners=False)
        res = res.sigmoid().data.cpu()
        res = res.numpy().squeeze()
        res = (res - res.min()) / (res.max() - res.min() + 1e-8)
        res = (res * 255).astype(np.uint8)
        # If you want to binarize the prediction results, please uncomment the following three lines. 
        # Note that this action will affect the calculation of evaluation metrics.
        # lambda = 0.5
        # res[res >= int(255 * lambda)] = 255
        # res[res < int(255 * lambda)] = 0
        print("Saving " + name)
        imageio.imsave(os.path.join(args.save_path, name[:-4] + ".png"), res)
