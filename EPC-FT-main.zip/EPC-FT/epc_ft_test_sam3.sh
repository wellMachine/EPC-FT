#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# Optional machine-specific paths; this file is excluded from version control.
if [[ -f configs/local.sh ]]; then source configs/local.sh; fi
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
args=(
  --model sam3
  --checkpoint "${SAM3_TRAINED_CHECKPOINT:-./output/epc_ft_sam3/epc-ft_sam3-80.pth}"
  --img_size "${SAM3_IMG_SIZE:-504}"
  --test_image_path "${TEST_IMAGE_PATH:-./data/COD/NC4K/Imgs/}"
  --test_gt_path "${TEST_GT_PATH:-./data/COD/NC4K/GT/}"
  --save_path "${SAM3_PREDICTION_PATH:-./result/epc_ft_sam3/NC4K/}"
)
exec "${PYTHON:-python}" epc_ft_test.py "${args[@]}" "$@"
