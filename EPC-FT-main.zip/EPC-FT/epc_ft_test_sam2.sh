#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# Optional machine-specific paths; this file is excluded from version control.
if [[ -f configs/local.sh ]]; then source configs/local.sh; fi
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
args=(
  --model sam2
  --checkpoint "${SAM2_TRAINED_CHECKPOINT:-./output/epc_ft_sam2/epc-ft_sam2-80.pth}"
  --img_size "${SAM2_IMG_SIZE:-672}"
  --test_image_path "${TEST_IMAGE_PATH:-./data/COD/NC4K/Imgs/}"
  --test_gt_path "${TEST_GT_PATH:-./data/COD/NC4K/GT/}"
  --save_path "${SAM2_PREDICTION_PATH:-./result/epc_ft_sam2/NC4K/}"
)
args+=(--sam2_type "${SAM2_TYPE:-l}")
exec "${PYTHON:-python}" epc_ft_test.py "${args[@]}" "$@"
