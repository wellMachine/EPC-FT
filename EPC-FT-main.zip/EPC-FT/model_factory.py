SUPPORTED_MODEL_NAMES = ("sam3", "sam2")


def _get_model_registry():
    from EPCFT import EPCFTSAM2, EPCFTSAM3

    return {
        "sam3": EPCFTSAM3,
        "sam2": EPCFTSAM2,
    }


def build_model(model_name="sam3", checkpoint_path=None, img_size=512, sam2_type="l", sam2_cfg=None):
    if model_name not in SUPPORTED_MODEL_NAMES:
        raise ValueError(f"Unsupported model name: {model_name}")

    registry = _get_model_registry()
    model_cls = registry[model_name]
    kwargs = {
        "checkpoint_path": checkpoint_path,
        "img_size": img_size,
    }
    if model_name == "sam2":
        kwargs["sam2_type"] = sam2_type
        kwargs["sam2_cfg"] = sam2_cfg
    return model_cls(**kwargs)
