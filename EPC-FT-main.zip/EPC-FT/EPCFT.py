import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint as cp
from functools import partial
import pywt
from timm.models.layers import trunc_normal_, DropPath
from sam2.build_sam import build_sam2
from sam3.model.vitdet import ViT, window_partition, window_unpartition
from adapter.adapter import CollaborativeAdapter, SAM2CollaborativeBlockAdapter


SAM2_CFG_ALIASES = {
    "t": "sam2_hiera_t.yaml",
    "s": "sam2_hiera_s.yaml",
    "b+": "sam2_hiera_b+.yaml",
    "l": "sam2_hiera_l.yaml",
}

SAM2_CHANNELS = {
    "sam2_hiera_t.yaml": [96, 192, 384, 768],
    "sam2_hiera_s.yaml": [96, 192, 384, 768],
    "sam2_hiera_b+.yaml": [112, 224, 448, 896],
    "sam2_hiera_l.yaml": [144, 288, 576, 1152],
}


def _normalize_sam2_cfg(sam2_type="l", sam2_cfg=None):
    if sam2_cfg is not None:
        if sam2_cfg in SAM2_CHANNELS:
            return sam2_cfg
        if sam2_cfg in SAM2_CFG_ALIASES:
            return SAM2_CFG_ALIASES[sam2_cfg]
        raise ValueError(f"Unsupported SAM2 config: {sam2_cfg}")

    if sam2_type in SAM2_CFG_ALIASES:
        return SAM2_CFG_ALIASES[sam2_type]
    if sam2_type in SAM2_CHANNELS:
        return sam2_type
    raise ValueError(f"Unsupported SAM2 type: {sam2_type}")


def _prune_sam2_for_segmentation(model):
    removable = [
        "sam_mask_decoder",
        "sam_prompt_encoder",
        "memory_encoder",
        "memory_attention",
        "mask_downsample",
        "obj_ptr_tpos_proj",
        "obj_ptr_proj",
    ]
    for name in removable:
        if hasattr(model, name):
            delattr(model, name)
    if hasattr(model.image_encoder, "neck"):
        delattr(model.image_encoder, "neck")
    return model.image_encoder.trunk


def _ensure_four_stage_features(features, expected_channels):
    if len(features) != 4:
        raise ValueError(f"SAM2 backbone must return 4 features, got {len(features)}")
    actual_channels = [feat.shape[1] for feat in features]
    if actual_channels != expected_channels:
        raise ValueError(
            f"SAM2 channels mismatch, expected {expected_channels}, got {actual_channels}"
        )


class LightweightRefinementBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv_in = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 4, 1),
            nn.BatchNorm2d(in_channels // 4, 1),
            nn.GELU()
        )
        self.conv_out = nn.Sequential(
            nn.Conv2d(in_channels // 2, out_channels, 1),
            nn.BatchNorm2d(out_channels, 1),
            nn.GELU()
        )
        self.dw1 = nn.Sequential(
            nn.Conv2d(in_channels // 8, in_channels // 8, kernel_size=3, stride=1, padding=1, groups=in_channels // 8),
            nn.BatchNorm2d(in_channels // 8),
            nn.GELU()
        )
        self.dw2 = nn.Sequential(
            nn.Conv2d(in_channels // 8, in_channels // 8, kernel_size=3, stride=1, padding=1, groups=in_channels // 8),
            nn.BatchNorm2d(in_channels // 8),
            nn.GELU()
        )

    def forward(self, x):
        x = self.conv_in(x)
        x1, x2 = torch.split(x, x.shape[1] // 2, 1)
        x3 = self.dw1(x2)
        x4 = self.dw2(x3)
        x = torch.cat([x1, x2, x3, x4], dim=1)
        x = self.conv_out(x)
        return x


class UncertaintyGuidedFusionBlock(nn.Module):
    """
    Uncertainty-guided spatial gating followed by lightweight refinement.
    """

    def __init__(self, in_channels, out_channels):
        super(UncertaintyGuidedFusionBlock, self).__init__()
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

        # 1. [新增] 一个极轻量的 1x1 卷积，用于压缩通道并生成不确定性图
        # 输入维度是拼接后的通道数 (in_channels)

        # 这是一个生成“置信度/不确定性图”的层。
        # 输出通道为 1 (共享不确定性)
        self.uncertainty_proj = nn.Sequential(
            nn.Conv2d(in_channels, 1, kernel_size=1),  # 1x1 卷积，参数极少
            nn.Sigmoid()  # 将值映射到 0~1，1代表确定(保留)，0代表极度不确定(抑制)
        )

        self.conv = LightweightRefinementBlock(in_channels, out_channels)

    def forward(self, x1, x2=None):
        # 1. 上采样
        x1 = self.up(x1)

        # 2. 拼接 (保持原有逻辑)
        if x2 is not None:
            diffY = x2.size()[2] - x1.size()[2]
            diffX = x2.size()[3] - x1.size()[3]
            x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                            diffY // 2, diffY - diffY // 2])
            x = torch.cat([x2, x1], dim=1)  # 注意：通常 FPN 是 x2 和 up(x1) 拼接
        else:
            x = x1

        # 3. Spatial reweighting
        # 此时 x 包含了深层语义和浅层细节

        # 生成不确定性图 (Uncertainty Map) / 置信度图 (Confidence Map)
        # 如果 Sigmoid 输出接近 1，表示高置信度；接近 0，表示高不确定性（需要抑制）
        uncertainty_map = self.uncertainty_proj(x)

        # 将不确定性图乘回去。
        # 使得网络能够自适应地忽略背景噪声或模糊特征。
        x = x * uncertainty_map

        # 4. 标准卷积
        return self.conv(x)


class SAM3CollaborativeBlockAdapter(nn.Module):
    """
    Wrapper for ViT Block that integrates CollaborativeAdapter and residual input adaptation.
    """

    def __init__(self, blk) -> None:
        super(SAM3CollaborativeBlockAdapter, self).__init__()
        self.block = blk
        dim = blk.attn.qkv.in_features

        # 1. Residual input adaptation (legacy parameter key: prompt_learn)
        self.prompt_learn = nn.Sequential(
            nn.Linear(dim, 32),
            nn.GELU(),
            nn.Linear(32, dim),
            nn.GELU()
        )

        # 2. Initialize CollaborativeAdapter
        # Bottleneck width used by the existing model.
        self.adapter = CollaborativeAdapter(dim=dim, hidden_dim=32)

        self.init_weights()

    def init_weights(self):
        def _init_weights(m):
            if isinstance(m, nn.Linear):
                trunc_normal_(m.weight, std=.02)
                if isinstance(m, nn.Linear) and m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.bias, 0)
                nn.init.constant_(m.weight, 1.0)

        self.prompt_learn.apply(_init_weights)

    def forward(self, x):
        # --- 0. Apply residual input adaptation ---
        # Insert adapter at the very beginning
        prompt = self.prompt_learn(x)
        x = x + prompt

        B, H, W, C = x.shape
        shortcut = x

        # --- 1. MHA Branch (Replicating Block Logic) ---
        x_norm1 = self.block.norm1(x)

        # Window Partition
        if self.block.window_size > 0:
            x_norm1_part, pad_hw = window_partition(x_norm1, self.block.window_size)
            x_attn = self.block.attn(x_norm1_part)
            x_attn = self.block.ls1(x_attn)  # Apply LayerScale
            x_mha = window_unpartition(x_attn, self.block.window_size, pad_hw, (H, W))
        else:
            x_attn = self.block.attn(x_norm1)
            x_mha = self.block.ls1(x_attn)

        # Apply drop path to MHA if needed?
        # Standard block: x = shortcut + drop_path(x_mha)
        # We will combine x_mha into the flow later.

        # --- 2. Collaborative Adapter ---
        # Reshape for adapter (B, N, C)
        x_flat = shortcut.flatten(1, 2)
        x_mha_flat = x_mha.flatten(1, 2)

        # Run adapter
        # Returns x_final (with Channel Adapter) and x_hat (Spatial Adapter out)
        x_final_flat, x_hat_flat = self.adapter(x_flat, x_mha_flat)

        # Reshape back to (B, H, W, C)
        x_final = x_final_flat.view(B, H, W, C)
        x_hat = x_hat_flat.view(B, H, W, C)

        # --- 3. Combined Input for MLP ---
        # Diagram: F_hat + F_mha feeds into MLP (Original) and Channel Adapter
        x_combined = x_hat + x_mha

        # --- 4. Original MLP Branch ---
        # Block logic: x = x + mlp(norm2(x))
        # Here input to norm2 is x_combined
        x_mlp_in = self.block.norm2(x_combined)
        x_mlp_orig = self.block.mlp(x_mlp_in)
        x_mlp_orig = self.block.ls2(x_mlp_orig)
        x_mlp_orig = self.block.drop_path(x_mlp_orig)
        x_mlp_orig = self.block.dropout(x_mlp_orig)

        # --- 5. Final Sum ---
        # Total Output = F_hat + F_mha + MLP_Orig + MLP_Adapter
        # We have x_final = x_hat + MLP_Adapter
        # So MLP_Adapter = x_final - x_hat
        # Total = x_hat + x_mha + MLP_Orig + (x_final - x_hat)
        #       = x_mha + MLP_Orig + x_final

        return x_mha + x_mlp_orig + x_final


def _create_vit_backbone(img_size):
    """Create ViT backbone for visual feature extraction."""
    return ViT(
        #   img_size=1008,
        img_size=img_size,
        pretrain_img_size=336,
        patch_size=14,
        embed_dim=1024,
        depth=32,
        num_heads=16,
        mlp_ratio=4.625,
        norm_layer="LayerNorm",
        drop_path_rate=0.1,
        qkv_bias=True,
        use_abs_pos=True,
        tile_abs_pos=True,
        global_att_blocks=(7, 15, 23, 31),
        rel_pos_blocks=(),
        use_rope=True,
        use_interp_rope=True,
        window_size=24,
        pretrain_use_cls_token=True,
        retain_cls_token=False,
        ln_pre=True,
        ln_post=False,
        return_interm_layers=True,
        bias_patch_embed=False,
        # compile_mode=compile_mode,
        compile_mode=None,
    )


def create_wavelet_filter(wave, in_size, out_size, type=torch.float):
    w = pywt.Wavelet(wave)
    dec_hi = torch.tensor(w.dec_hi[::-1], dtype=type)
    dec_lo = torch.tensor(w.dec_lo[::-1], dtype=type)
    dec_filters = torch.stack([dec_lo.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_lo.unsqueeze(0) * dec_hi.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_lo.unsqueeze(1),
                               dec_hi.unsqueeze(0) * dec_hi.unsqueeze(1)], dim=0)
    dec_filters = dec_filters[:, None].repeat(in_size, 1, 1, 1)
    rec_hi = torch.tensor(w.rec_hi[::-1], dtype=type).flip(dims=[0])
    rec_lo = torch.tensor(w.rec_lo[::-1], dtype=type).flip(dims=[0])
    rec_filters = torch.stack([rec_lo.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_lo.unsqueeze(0) * rec_hi.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_lo.unsqueeze(1),
                               rec_hi.unsqueeze(0) * rec_hi.unsqueeze(1)], dim=0)
    rec_filters = rec_filters[:, None].repeat(out_size, 1, 1, 1)
    return dec_filters, rec_filters


def wavelet_transform(x, filters):
    b, c, h, w = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = F.conv2d(x, filters, stride=2, groups=c, padding=pad)
    x = x.reshape(b, c, 4, h // 2, w // 2)
    return x


def inverse_wavelet_transform(x, filters):
    b, c, _, h_half, w_half = x.shape
    pad = (filters.shape[2] // 2 - 1, filters.shape[3] // 2 - 1)
    x = x.reshape(b, c * 4, h_half, w_half)
    x = F.conv_transpose2d(x, filters, stride=2, groups=c, padding=pad)
    return x


class _ScaleModule(nn.Module):
    def __init__(self, dims, init_scale=1.0, init_bias=0):
        super(_ScaleModule, self).__init__()
        self.dims = dims
        self.weight = nn.Parameter(torch.ones(*dims) * init_scale)
        self.bias = None

    def forward(self, x):
        return torch.mul(self.weight, x)


class WTConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=5, stride=1, bias=True, wt_levels=1, wt_type='db1'):
        super(WTConv2d, self).__init__()
        assert in_channels == out_channels
        self.in_channels = in_channels
        self.wt_levels = wt_levels
        self.stride = stride
        self.dilation = 1
        self.wt_filter, self.iwt_filter = create_wavelet_filter(wt_type, in_channels, in_channels, torch.float)
        self.wt_filter = nn.Parameter(self.wt_filter, requires_grad=False)
        self.iwt_filter = nn.Parameter(self.iwt_filter, requires_grad=False)
        self.wt_function = partial(wavelet_transform, filters=self.wt_filter)
        self.iwt_function = partial(inverse_wavelet_transform, filters=self.iwt_filter)
        self.base_conv = nn.Conv2d(in_channels, in_channels, kernel_size, padding='same', stride=1, dilation=1,
                                   groups=in_channels, bias=bias)
        self.base_scale = _ScaleModule([1, in_channels, 1, 1])
        self.wavelet_convs = nn.ModuleList(
            [nn.Conv2d(in_channels * 4, in_channels * 4, kernel_size, padding='same', stride=1, dilation=1,
                       groups=in_channels * 4, bias=False) for _ in range(self.wt_levels)]
        )
        self.wavelet_scale = nn.ModuleList(
            [_ScaleModule([1, in_channels * 4, 1, 1], init_scale=0.1) for _ in range(self.wt_levels)]
        )
        if self.stride > 1:
            self.stride_filter = nn.Parameter(torch.ones(in_channels, 1, 1, 1), requires_grad=False)
            self.do_stride = lambda x_in: F.conv2d(x_in, self.stride_filter, bias=None, stride=self.stride,
                                                   groups=in_channels)
        else:
            self.do_stride = None

    def forward(self, x):
        x_ll_in_levels = []
        x_h_in_levels = []
        shapes_in_levels = []
        curr_x_ll = x
        for i in range(self.wt_levels):
            curr_shape = curr_x_ll.shape
            shapes_in_levels.append(curr_shape)
            if (curr_shape[2] % 2 > 0) or (curr_shape[3] % 2 > 0):
                curr_pads = (0, curr_shape[3] % 2, 0, curr_shape[2] % 2)
                curr_x_ll = F.pad(curr_x_ll, curr_pads)
            curr_x = self.wt_function(curr_x_ll)
            curr_x_ll = curr_x[:, :, 0, :, :]
            shape_x = curr_x.shape
            curr_x_tag = curr_x.reshape(shape_x[0], shape_x[1] * 4, shape_x[3], shape_x[4])
            curr_x_tag = self.wavelet_scale[i](self.wavelet_convs[i](curr_x_tag))
            curr_x_tag = curr_x_tag.reshape(shape_x)
            x_ll_in_levels.append(curr_x_tag[:, :, 0, :, :])
            x_h_in_levels.append(curr_x_tag[:, :, 1:4, :, :])
        next_x_ll = 0
        for i in range(self.wt_levels - 1, -1, -1):
            curr_x_ll = x_ll_in_levels.pop()
            curr_x_h = x_h_in_levels.pop()
            curr_shape = shapes_in_levels.pop()
            curr_x_ll = curr_x_ll + next_x_ll
            curr_x = torch.cat([curr_x_ll.unsqueeze(2), curr_x_h], dim=2)
            next_x_ll = self.iwt_function(curr_x)
            next_x_ll = next_x_ll[:, :, :curr_shape[2], :curr_shape[3]]
        x_tag = next_x_ll
        x = self.base_scale(self.base_conv(x))
        x = x + x_tag
        if self.do_stride is not None:
            x = self.do_stride(x)
        return x


class AtrousConvExpert(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(AtrousConvExpert, self).__init__()
        self.Conv_1 = nn.Sequential(*[
            nn.Conv2d(in_channels, out_channels // 4, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.ATConv_3 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=3, stride=1, dilation=3, padding=3, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.ATConv_5 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=3, stride=1, dilation=5, padding=5, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.ATConv_7 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=3, stride=1, dilation=7, padding=7, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.reduce = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        x = self.Conv_1(x)
        x1 = self.ATConv_3(x)
        x2 = self.ATConv_5(x + x1)
        x3 = self.ATConv_7(x + x2)
        x = self.reduce(torch.cat([x1, x2, x3, x], 1))
        return x


class DepthwiseConvExpert(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DepthwiseConvExpert, self).__init__()
        self.Conv_1 = nn.Sequential(*[
            nn.Conv2d(in_channels, out_channels // 4, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.DConv_3 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=3, stride=1, padding=1, groups=in_channels // 4,
                      bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.DConv_5 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=5, stride=1, padding=2, groups=out_channels // 4,
                      bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.DConv_7 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=7, stride=1, padding=3, groups=out_channels // 4,
                      bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.reduce = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        x = self.Conv_1(x)
        x1 = self.DConv_3(x)
        x2 = self.DConv_5(x + x1)
        x3 = self.DConv_7(x + x2)
        x = self.reduce(torch.cat([x1, x2, x3, x], 1))
        return x


class LargeKernelExpert(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(LargeKernelExpert, self).__init__()
        self.Conv_1 = nn.Sequential(*[
            nn.Conv2d(in_channels, out_channels // 4, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        # 7x7 Depthwise
        self.LK_7 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=7, stride=1, padding=3, groups=out_channels // 4,
                      bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        # 9x9 Depthwise
        self.LK_9 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=9, stride=1, padding=4, groups=out_channels // 4,
                      bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        # 11x11 Depthwise
        self.LK_11 = nn.Sequential(*[
            nn.Conv2d(in_channels // 4, out_channels // 4, kernel_size=11, stride=1, padding=5,
                      groups=out_channels // 4, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.reduce = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        x = self.Conv_1(x)
        x1 = self.LK_7(x)
        x2 = self.LK_9(x + x1)
        x3 = self.LK_11(x + x2)
        x = self.reduce(torch.cat([x1, x2, x3, x], 1))
        return x


class DiscreteWaveletConvExpert(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DiscreteWaveletConvExpert, self).__init__()
        self.Conv_1 = nn.Sequential(*[
            nn.Conv2d(in_channels, out_channels // 4, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.WTConv_3 = nn.Sequential(*[
            WTConv2d(in_channels // 4, out_channels // 4, kernel_size=3, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.WTConv_5 = nn.Sequential(*[
            WTConv2d(in_channels // 4, out_channels // 4, kernel_size=5, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.WTConv_7 = nn.Sequential(*[
            WTConv2d(in_channels // 4, out_channels // 4, kernel_size=7, bias=True),
            nn.BatchNorm2d(out_channels // 4),
            nn.ReLU(inplace=True),
        ])
        self.reduce = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=1, bias=True),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        x = self.Conv_1(x)
        x1 = self.WTConv_3(x)
        x2 = self.WTConv_5(x + x1)
        x3 = self.WTConv_7(x + x2)
        x = self.reduce(torch.cat([x1, x2, x3, x], 1))
        return x


class PixelWiseGatingNetwork(nn.Module):
    def __init__(self, in_features, experts):
        super(PixelWiseGatingNetwork, self).__init__()
        # Use 1x1 Conv for Spatial-wise Gating instead of Linear
        self.conv = nn.Conv2d(in_features, experts, kernel_size=1)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        # Input x: (B, C, H, W)
        # Output: (B, Experts, H, W) - Spatial Weight Map
        x = self.conv(x)
        return self.softmax(x)


class SpatialPriorExpertEnsemble(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(SpatialPriorExpertEnsemble, self).__init__()
        self.expert_a = DepthwiseConvExpert(in_channels, out_channels)
        self.expert_b = AtrousConvExpert(in_channels, out_channels)
        self.expert_c = LargeKernelExpert(in_channels, out_channels)
        self.expert_d = DiscreteWaveletConvExpert(in_channels, out_channels)
        self.gating_network = PixelWiseGatingNetwork(in_features=in_channels, experts=4)

    def forward(self, x):
        # x: (B, C, H, W)
        # Generate Spatial Gating Weights: (B, 4, H, W)
        gate_weights = self.gating_network(x)

        output_a = self.expert_a(x)
        output_b = self.expert_b(x)
        output_c = self.expert_c(x)
        output_d = self.expert_d(x)

        # Spatial-wise weighted sum
        # gate_weights[:, i] is (B, H, W), unsqueeze to (B, 1, H, W) for broadcasting
        output = (gate_weights[:, 0].unsqueeze(1) * output_a +
                  gate_weights[:, 1].unsqueeze(1) * output_b +
                  gate_weights[:, 2].unsqueeze(1) * output_c +
                  gate_weights[:, 3].unsqueeze(1) * output_d)
        return output


class DynamicMultiScaleSpatialPriorEnsemble(nn.Module):  # Dynamic Multi-scale Spatial Prior Ensemble (D-MSPE)
    def __init__(self, inplanes=64, embed_dim=384, with_cp=False):
        super().__init__()
        self.with_cp = with_cp
        self.stem = nn.Sequential(*[
            nn.Conv2d(3, inplanes, kernel_size=3, stride=2, padding=1, bias=True),
            nn.BatchNorm2d(inplanes),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        ])
        self.conv2 = nn.Sequential(*[
            nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=2, padding=1, bias=True),
            nn.BatchNorm2d(inplanes),
            nn.ReLU(inplace=True),
        ])
        self.conv3 = nn.Sequential(*[
            nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=2, padding=1, bias=True),
            nn.BatchNorm2d(inplanes),
            nn.ReLU(inplace=True)
        ])
        self.conv4 = nn.Sequential(*[
            nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=2, padding=1, bias=True),
            nn.BatchNorm2d(inplanes),
            nn.ReLU(inplace=True)
        ])
        self.MoEConv = SpatialPriorExpertEnsemble(inplanes, inplanes)
        self.fc1 = nn.Conv2d(inplanes, embed_dim, kernel_size=1, stride=1, padding=0, bias=True)

    def forward(self, x):
        def _inner_forward(x):
            c1 = self.stem(x)
            c1 = c1 + self.MoEConv(c1)
            c2 = self.conv2(c1)
            c2 = c2 + self.MoEConv(c2)
            c3 = self.conv3(c2)
            c3 = c3 + self.MoEConv(c3)
            c4 = self.conv4(c3)
            c4 = c4 + self.MoEConv(c4)
            c1_out = self.fc1(c1)
            c2_out = self.fc1(c2)
            c3_out = self.fc1(c3)
            c4_out = self.fc1(c4)
            return c1_out, c2_out, c3_out, c4_out

        if self.with_cp and x.requires_grad:
            outs = cp.checkpoint(_inner_forward, x)
        else:
            outs = _inner_forward(x)
        return outs


class EPCFTSAM3(nn.Module):
    def __init__(self, checkpoint_path=None, img_size=504) -> None:
        super(EPCFTSAM3, self).__init__()
        # D-MSPE initialization. Output dim 128 to match reduce layers.
        self.dmlp = DynamicMultiScaleSpatialPriorEnsemble(inplanes=64, embed_dim=128)
        self.sam3_vit = _create_vit_backbone(img_size)
        if checkpoint_path:
            ckpt = torch.load(checkpoint_path, map_location="cpu")
            new_ckpt = dict()
            for k, v in ckpt.items():
                if "detector.backbone.vision_backbone.trunk" in k and 'freqs_cis' not in k:
                    new_ckpt[k[len("detector.backbone.vision_backbone.trunk."):]] = v
            self.sam3_vit.load_state_dict(new_ckpt, strict=False)
        for param in self.sam3_vit.parameters():
            param.requires_grad = False
        blocks = []
        for block in self.sam3_vit.blocks:
            blocks.append(
                SAM3CollaborativeBlockAdapter(block)
            )
        self.sam3_vit.blocks = nn.Sequential(
            *blocks
        )

        self.reduce1 = nn.Conv2d(1024, 128, 1)
        self.reduce2 = nn.Conv2d(1024, 128, 1)
        self.reduce3 = nn.Conv2d(1024, 128, 1)
        self.reduce4 = nn.Conv2d(1024, 128, 1)

        # Revert to Up blocks but using UncertaintyGuidedFusionBlock
        self.up1 = UncertaintyGuidedFusionBlock(256, 128)
        self.up2 = UncertaintyGuidedFusionBlock(256, 128)
        self.up3 = UncertaintyGuidedFusionBlock(256, 128)
        self.up4 = UncertaintyGuidedFusionBlock(128, 128)

        self.head = nn.Conv2d(128, 1, 1)

    def _semantic_features(self, x):
        # Global-attention block indices 7, 15, 23, 31 (layers 8, 16, 24, 32).
        features = self.sam3_vit(x)
        if len(features) != 4:
            raise RuntimeError(f"Expected four SAM3 block outputs, got {len(features)}")
        return tuple(features)

    def forward(self, x):
        # D-MSPE Branch
        # c1: H/4, c2: H/8, c3: H/16, c4: H/32
        c1, c2, c3, c4 = self.dmlp(x)

        B, C, H, W = x.shape
        v1, v2, v3, v4 = self._semantic_features(x)
        x1 = F.interpolate(self.reduce1(v1), size=(H // 4, W // 4), mode='bilinear', align_corners=True)
        x2 = F.interpolate(self.reduce2(v2), size=(H // 8, W // 8), mode='bilinear', align_corners=True)
        x3 = F.interpolate(self.reduce3(v3), size=(H // 16, W // 16), mode='bilinear', align_corners=True)
        x4 = F.interpolate(self.reduce4(v4), size=(H // 32, W // 32), mode='bilinear', align_corners=True)

        # Fuse D-MSPE features
        if c1.shape[-2:] != x1.shape[-2:]:
            c1 = F.interpolate(c1, size=x1.shape[-2:], mode='bilinear', align_corners=True)
        x1 = x1 + c1

        if c2.shape[-2:] != x2.shape[-2:]:
            c2 = F.interpolate(c2, size=x2.shape[-2:], mode='bilinear', align_corners=True)
        x2 = x2 + c2

        if c3.shape[-2:] != x3.shape[-2:]:
            c3 = F.interpolate(c3, size=x3.shape[-2:], mode='bilinear', align_corners=True)
        x3 = x3 + c3

        if c4.shape[-2:] != x4.shape[-2:]:
            c4 = F.interpolate(c4, size=x4.shape[-2:], mode='bilinear', align_corners=True)
        x4 = x4 + c4

        # Decoder path with UncertaintyGuidedFusionBlock
        # x4: H/32. up4(x4) -> H/16
        x = self.up4(x4)

        # x: H/16, x3: H/16. up3(x, x3) -> H/8
        x = self.up3(x, x3)

        # x: H/8, x2: H/8. up2(x, x2) -> H/4
        x = self.up2(x, x2)

        # x: H/4, x1: H/4. up1(x, x1) -> H/2
        x = self.up1(x, x1)

        out = self.head(x)
        out = F.interpolate(out, size=(H, W), mode='bilinear', align_corners=True)

        return out


class EPCFTSAM2(nn.Module):
    def __init__(self, checkpoint_path=None, img_size=512, sam2_type="l", sam2_cfg=None) -> None:
        super(EPCFTSAM2, self).__init__()
        self.sam2_cfg_name = _normalize_sam2_cfg(sam2_type=sam2_type, sam2_cfg=sam2_cfg)
        self.sam2_channels = SAM2_CHANNELS[self.sam2_cfg_name]

        if checkpoint_path is not None and not os.path.isfile(checkpoint_path):
            raise FileNotFoundError(f"SAM2 checkpoint not found: {checkpoint_path}")

        self.dmlp = DynamicMultiScaleSpatialPriorEnsemble(inplanes=64, embed_dim=128)

        sam2_model = build_sam2(
            self.sam2_cfg_name,
            checkpoint_path,
            device="cpu",
            mode="eval",
            apply_postprocessing=False,
        )
        self.sam2_encoder = _prune_sam2_for_segmentation(sam2_model)

        for param in self.sam2_encoder.parameters():
            param.requires_grad = False

        self.sam2_encoder.blocks = nn.Sequential(
            *[SAM2CollaborativeBlockAdapter(block) for block in self.sam2_encoder.blocks]
        )

        self.reduce1 = nn.Conv2d(self.sam2_channels[0], 128, 1)
        self.reduce2 = nn.Conv2d(self.sam2_channels[1], 128, 1)
        self.reduce3 = nn.Conv2d(self.sam2_channels[2], 128, 1)
        self.reduce4 = nn.Conv2d(self.sam2_channels[3], 128, 1)

        self.up1 = UncertaintyGuidedFusionBlock(256, 128)
        self.up2 = UncertaintyGuidedFusionBlock(256, 128)
        self.up3 = UncertaintyGuidedFusionBlock(256, 128)
        self.up4 = UncertaintyGuidedFusionBlock(128, 128)
        self.head = nn.Conv2d(128, 1, 1)

    def forward(self, x):
        c1, c2, c3, c4 = self.dmlp(x)
        _, _, h, w = x.shape

        features = self.sam2_encoder(x)
        _ensure_four_stage_features(features, self.sam2_channels)
        f1, f2, f3, f4 = features

        x1 = self.reduce1(f1)
        x2 = self.reduce2(f2)
        x3 = self.reduce3(f3)
        x4 = self.reduce4(f4)

        if c1.shape[-2:] != x1.shape[-2:]:
            c1 = F.interpolate(c1, size=x1.shape[-2:], mode='bilinear', align_corners=True)
        x1 = x1 + c1

        if c2.shape[-2:] != x2.shape[-2:]:
            c2 = F.interpolate(c2, size=x2.shape[-2:], mode='bilinear', align_corners=True)
        x2 = x2 + c2

        if c3.shape[-2:] != x3.shape[-2:]:
            c3 = F.interpolate(c3, size=x3.shape[-2:], mode='bilinear', align_corners=True)
        x3 = x3 + c3

        if c4.shape[-2:] != x4.shape[-2:]:
            c4 = F.interpolate(c4, size=x4.shape[-2:], mode='bilinear', align_corners=True)
        x4 = x4 + c4

        x = self.up4(x4)
        x = self.up3(x, x3)
        x = self.up2(x, x2)
        x = self.up1(x, x1)

        out = self.head(x)
        out = F.interpolate(out, size=(h, w), mode='bilinear', align_corners=True)
        return out
