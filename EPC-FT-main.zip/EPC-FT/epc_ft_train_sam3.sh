#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# Optional machine-specific paths; this file is excluded from version control.
if [[ -f configs/local.sh ]]; then source configs/local.sh; fi
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
args=(
  --model sam3
  --checkpoint_path "${SAM3_BACKBONE_CHECKPOINT:-./checkpoints/sam3.pt}"
  --img_size "${SAM3_IMG_SIZE:-504}"
  --train_image_path "${TRAIN_IMAGE_PATH:-./data/COD/Train/Imgs/}"
  --train_mask_path "${TRAIN_MASK_PATH:-./data/COD/Train/GT/}"
  --save_path "${SAM3_SAVE_PATH:-./output/epc_ft_sam3/}"
  --epoch "${EPOCHS:-80}"
  --lr "${LR:-0.0002}"
  --batch_size "${SAM3_BATCH_SIZE:-12}"
)
if [[ -n "${VAL_IMAGE_PATH:-}" || -n "${VAL_MASK_PATH:-}" ]]; then
  args+=(--val_image_path "${VAL_IMAGE_PATH:-}" --val_mask_path "${VAL_MASK_PATH:-}")
fi
exec "${PYTHON:-python}" epc_ft_train.py "${args[@]}" "$@"
