import torch
import torch.nn as nn
import math
import torch.nn.functional as F
from sam2.modeling.backbones.utils import window_partition, window_unpartition


def _do_pool(x: torch.Tensor, pool: nn.Module, norm: nn.Module = None) -> torch.Tensor:
    if pool is None:
        return x
    x = x.permute(0, 3, 1, 2)
    x = pool(x)
    x = x.permute(0, 2, 3, 1)
    if norm is not None:
        x = norm(x)
    return x


class CollaborativeAdapter(nn.Module):
    """
    CollaborativeAdapter module for EPC-FT.
    Consists of an Spatial Adapter (spatial/linear) and an Channel Adapter (channel recalibration).
    """

    def __init__(self, dim: int, hidden_dim: int = 32, kernel_size: int = 1):
        """
        Args:
            dim: Input feature dimension.
            hidden_dim: Bottleneck dimension for the Channel Adapter.
            kernel_size: Kernel size for the Spatial Adapter's convolution (default 1).
        """
        super().__init__()

        # Learnable Scaling Factors
        # Initialized to 0.1
        self.s_f = nn.Parameter(torch.tensor(0.1))
        self.s_m = nn.Parameter(torch.tensor(0.1))

        # --- Spatial Adapter Layers (Spatial adaptation) ---
        # Linear Layer 1 (W1): dim -> hidden_dim (Bottleneck)
        self.fc_w1 = nn.Linear(dim, hidden_dim)

        # Conv2d Layer (Wc): hidden_dim -> hidden_dim
        padding = (kernel_size - 1) // 2
        self.fc_wc = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=kernel_size, padding=padding)

        # Linear Layer 2 (W2): hidden_dim -> dim
        self.fc_w2 = nn.Linear(hidden_dim, dim)

        # --- Channel Adapter Layers (Channel adaptation) ---
        # Down Projection (W_down: dim -> hidden_dim)
        self.mlp_down = nn.Linear(dim, hidden_dim)

        # Activation
        self.relu = nn.ReLU()

        # Up Projection (W_up: hidden_dim -> dim)
        self.mlp_up = nn.Linear(hidden_dim, dim)

    def forward(self, x: torch.Tensor, x_mha: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Input features from previous layer, shape [B, N, C].
            x_mha: Output features from the Multi-Head Attention layer of SAM, shape [B, N, C].

        Returns:
            x_final: Processed features, shape [B, N, C].
        """
        B, N, C = x.shape

        # Calculate H and W assuming square image and N = H * W
        H = int(math.sqrt(N))
        W = H

        if H * W != N:
            raise ValueError("CollaborativeAdapter expects a square spatial token grid")

        # --- Step 1: Spatial Adapter Calculation (F_hat) ---
        # Apply Linear 1 to x
        x_fc = self.fc_w1(x)  # [B, N, hidden_dim]

        # Reshape/Permute to [B, hidden_dim, H, W]
        # x_fc is [B, N, hidden_dim] -> permute to [B, hidden_dim, N] -> view to [B, hidden_dim, H, W]
        current_dim = x_fc.shape[-1]
        x_fc = x_fc.transpose(1, 2).view(B, current_dim, H, W)

        # Apply Conv2d
        x_fc = self.fc_wc(x_fc)  # [B, hidden_dim, H, W]

        # Reshape/Permute back to [B, N, hidden_dim]
        # [B, C, H, W] -> flatten to [B, C, N] -> transpose to [B, N, C]
        x_fc = x_fc.flatten(2).transpose(1, 2)

        # Apply Linear 2
        x_fc = self.fc_w2(x_fc)

        # Apply scaling: x + s_f * output
        x_hat = x + self.s_f * x_fc

        # --- Step 2: Channel Adapter Calculation (F_tilde) ---
        # Combine inputs: (x_hat + x_mha)
        mlp_in = x_hat + x_mha

        # Apply Down Projection -> ReLU -> Up Projection
        mlp_out = self.mlp_down(mlp_in)
        mlp_out = self.relu(mlp_out)
        mlp_out = self.mlp_up(mlp_out)

        # Apply scaling and residual: x_hat + s_m * output
        x_final = x_hat + self.s_m * mlp_out

        return x_final, x_hat


class SAM2CollaborativeBlockAdapter(nn.Module):
    """
    SAM2 block wrapper that preserves the CollaborativeAdapter structure while
    aligning stage-changed features to the block output shape.
    """

    def __init__(self, blk, hidden_dim: int = 32):
        super().__init__()
        self.block = blk
        self.dim_in = blk.attn.qkv.in_features
        self.dim_out = getattr(blk, "dim_out", self.dim_in)
        prompt_hidden_dim = min(hidden_dim, self.dim_in)
        adapter_hidden_dim = min(hidden_dim, self.dim_out)

        self.prompt_learn = nn.Sequential(
            nn.Linear(self.dim_in, prompt_hidden_dim),
            nn.GELU(),
            nn.Linear(prompt_hidden_dim, self.dim_in),
            nn.GELU(),
        )
        self.adapter = CollaborativeAdapter(dim=self.dim_out, hidden_dim=adapter_hidden_dim)
        self.init_weights()

    def init_weights(self):
        for module in self.prompt_learn:
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_prompt = x + self.prompt_learn(x)

        shortcut = x_prompt
        x_norm1 = self.block.norm1(x_prompt)

        if self.dim_in != self.dim_out:
            if not hasattr(self.block, "proj"):
                raise ValueError("SAM2 stage-change block is missing projection weights")
            shortcut = _do_pool(self.block.proj(x_norm1), getattr(self.block, "pool", None))

        window_size = getattr(self.block, "window_size", 0)
        if window_size > 0:
            h_in, w_in = x_norm1.shape[1:3]
            x_attn_in, pad_hw = window_partition(x_norm1, window_size)
            x_attn = self.block.attn(x_attn_in)
        else:
            x_attn = self.block.attn(x_norm1)

        if getattr(self.block, "q_stride", None):
            window_size = self.block.window_size // self.block.q_stride[0]
            h_in, w_in = shortcut.shape[1:3]
            pad_h = (window_size - h_in % window_size) % window_size
            pad_w = (window_size - w_in % window_size) % window_size
            pad_hw = (h_in + pad_h, w_in + pad_w)

        if getattr(self.block, "window_size", 0) > 0:
            x_attn = window_unpartition(x_attn, window_size, pad_hw, (h_in, w_in))

        x_mha = x_attn

        b, h2, w2, c2 = x_mha.shape
        if c2 != self.dim_out:
            raise ValueError(f"Unexpected SAM2 attention channels: expected {self.dim_out}, got {c2}")
        if h2 != w2:
            raise ValueError("SAM2CollaborativeBlockAdapter expects square spatial tokens for CollaborativeAdapter")

        shortcut_flat = shortcut.reshape(b, h2 * w2, c2)
        x_mha_flat = x_mha.reshape(b, h2 * w2, c2)

        x_final_flat, x_hat_flat = self.adapter(shortcut_flat, x_mha_flat)
        x_final = x_final_flat.reshape(b, h2, w2, c2)
        x_hat = x_hat_flat.reshape(b, h2, w2, c2)

        x_combined = x_hat + x_mha
        x_mlp_orig = self.block.drop_path(self.block.mlp(self.block.norm2(x_combined)))
        return x_mha + x_mlp_orig + x_final

