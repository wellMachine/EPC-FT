# EPC-FT: Expert-Prior Collaborative Fine-Tuning for Binary Segmentation with SAM

EPC-FT adapts frozen SAM image encoders for binary segmentation using a **Dynamic Multi-scale Spatial Prior Ensemble (D-MSPE)**, a **Collaborative Adapter (CA)**, and an **Uncertainty-Guided Fusion Decoder**.

## Repository structure

```text
EPCFT.py                   EPCFTSAM3 and EPCFTSAM2 models
adapter/adapter.py         Collaborative Adapter and SAM2 block wrapper
model_factory.py           Backbone selection: sam3 / sam2
dataset.py                 Training and test data loading
epc_ft_train.py            Shared training entry point
epc_ft_test.py             Shared inference entry point
epc_ft_train_sam3.sh        SAM3 training
epc_ft_test_sam3.sh         SAM3 inference
epc_ft_train_sam2.sh        SAM2 training
epc_ft_test_sam2.sh         SAM2 inference
configs/local.example.sh   Example data and checkpoint paths
sam3/, sam2/, sam2_configs/ Backbone implementation and configurations
```

## Model details

- **SAM3** uses features after Transformer layers **8, 16, 24, and 32**. Four independent 1×1 projections map them to 128 channels, followed by resizing to input resolutions 1/4, 1/8, 1/16, and 1/32.
- **SAM2** uses four hierarchical image-encoder outputs, each independently projected to 128 channels.
- **D-MSPE** extracts four-scale priors using Depthwise Conv, Atrous Conv, Large Kernel, and Discrete Wavelet Conv experts. Pixel-wise Softmax gating combines expert outputs.
- Each semantic feature is added to its corresponding D-MSPE prior before decoding. These fused features are not fed back into the backbone's next Transformer block.
- **CA** performs spatial adaptation followed by channel adaptation. The existing residual input MLP is also retained; it does not append extra prompt tokens.
- Training uses weighted binary cross-entropy plus weighted IoU loss.

The SAM3 implementation here is the four-depth variant. Its results must be evaluated separately from earlier experiments that used only the final backbone feature.

## Setup

Use Python 3.10 or later. Install a matching PyTorch and torchvision pair suitable for your GPU, then install dependencies:

```bash
pip install -r requirements.txt
```

The entry points were checked in a Python 3.10 environment with PyTorch 2.4.1. A fresh dependency installation and full GPU training have not been verified as part of this cleanup.

Obtain pretrained weights from [SAM3](https://github.com/facebookresearch/sam3) and [SAM2](https://github.com/facebookresearch/sam2). Place `sam3.pt` and `sam2_hiera_large.pt` in `checkpoints/`, or specify their paths in your local configuration. The supplied SAM2 configuration defaults to Hiera-L.

## Configure data

```bash
cp configs/local.example.sh configs/local.sh
```

Edit `configs/local.sh` to specify pretrained checkpoints, training images/masks, and test images/ground-truth masks. Validation is optional; set both validation paths when using it. Test ground truth is used to recover the original output size. `configs/local.sh` is machine-specific and excluded from version control.

Images and masks should have matching filenames and follow the layout used by `dataset.py`.

## Train

```bash
bash epc_ft_train_sam3.sh
bash epc_ft_train_sam2.sh
```

| Script | Input size | Batch size | Epochs | Learning rate |
|---|---:|---:|---:|---:|
| SAM3 | 504 × 504 | 12 | 80 | 2e-4 |
| SAM2 | 672 × 672 | 4 | 80 | 2e-4 |

These defaults retain the local experiment settings; they are not a claim that all submitted-paper results used this protocol. The manuscript's stated default protocol is 504 × 504, batch size 8, and 100 epochs. Match the configuration to the experiment being reproduced.

Options passed to the shell script override its defaults:

```bash
bash epc_ft_train_sam3.sh --img_size 504 --batch_size 8 --epoch 100
bash epc_ft_train_sam2.sh --img_size 512 --batch_size 8 --epoch 100
```

Default checkpoints are saved under `output/epc_ft_sam3/` or `output/epc_ft_sam2/`. Epoch checkpoints use `epc-ft_<backbone>-<epoch>.pth`. When validation is configured, the checkpoint with the best validation S-measure is also saved as `epc-ft_<backbone>_best.pth`.

## Test

```bash
bash epc_ft_test_sam3.sh
bash epc_ft_test_sam2.sh
```

The default test scripts use epoch 80 and the corresponding training input size. Specify the desired checkpoint and training resolution when testing another experiment:

```bash
bash epc_ft_test_sam3.sh --checkpoint ./output/epc_ft_sam3/epc-ft_sam3-100.pth --img_size 504
bash epc_ft_test_sam2.sh --checkpoint ./output/epc_ft_sam2/epc-ft_sam2-100.pth --img_size 512
```

The saved trained checkpoint contains the frozen backbone as well as adaptation and decoder parameters, so testing does not require a separate pretrained checkpoint. Predictions are saved under `result/epc_ft_<backbone>/NC4K/` by default. The test entry point generates prediction maps; it does not report benchmark metrics.

## Existing checkpoints

Registered parameter names are retained to support the existing trained weights. In particular, the earlier `sam3_new` four-depth checkpoint can be loaded with `--model sam3`; no file rename is necessary. This does not make an earlier final-feature-only checkpoint equivalent to the four-depth model.

## Public release

Release the source files, four shell scripts, dependency list, configuration example, and upstream backbone source/configurations. `.gitignore` excludes local configuration, previous code backups, model weights, prediction maps, private PDFs, and datasets. No repository has been published by this cleanup.

## Acknowledgements and license

This implementation incorporates code from [SAM3](https://github.com/facebookresearch/sam3), [SAM2](https://github.com/facebookresearch/sam2), and [SAM2-UNet](https://github.com/WZH0120/SAM2-UNet/). Retain upstream copyright and license notices. The existing license file is `LICENSE.txt`; this cleanup does not change upstream licensing.
