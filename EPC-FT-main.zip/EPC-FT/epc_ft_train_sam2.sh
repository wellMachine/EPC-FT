#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# Optional machine-specific paths; this file is excluded from version control.
if [[ -f configs/local.sh ]]; then source configs/local.sh; fi
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
args=(
  --model sam2
  --checkpoint_path "${SAM2_BACKBONE_CHECKPOINT:-./checkpoints/sam2_hiera_large.pt}"
  --img_size "${SAM2_IMG_SIZE:-672}"
  --train_image_path "${TRAIN_IMAGE_PATH:-./data/COD/Train/Imgs/}"
  --train_mask_path "${TRAIN_MASK_PATH:-./data/COD/Train/GT/}"
  --save_path "${SAM2_SAVE_PATH:-./output/epc_ft_sam2/}"
  --epoch "${EPOCHS:-80}"
  --lr "${LR:-0.0002}"
  --batch_size "${SAM2_BATCH_SIZE:-4}"
)
if [[ -n "${VAL_IMAGE_PATH:-}" || -n "${VAL_MASK_PATH:-}" ]]; then
  args+=(--val_image_path "${VAL_IMAGE_PATH:-}" --val_mask_path "${VAL_MASK_PATH:-}")
fi
args+=(--sam2_type "${SAM2_TYPE:-l}")
exec "${PYTHON:-python}" epc_ft_train.py "${args[@]}" "$@"
