# Copy to configs/local.sh and set your own paths.
SAM3_BACKBONE_CHECKPOINT="./checkpoints/sam3.pt"
SAM2_BACKBONE_CHECKPOINT="./checkpoints/sam2_hiera_large.pt"
TRAIN_IMAGE_PATH="./data/COD/Train/Imgs/"
TRAIN_MASK_PATH="./data/COD/Train/GT/"
TEST_IMAGE_PATH="./data/COD/NC4K/Imgs/"
TEST_GT_PATH="./data/COD/NC4K/GT/"
# Optional validation: supply both paths.
# VAL_IMAGE_PATH="./data/COD/Validation/Imgs/"
# VAL_MASK_PATH="./data/COD/Validation/GT/"
# SAM3_TRAINED_CHECKPOINT="./output/epc_ft_sam3/epc-ft_sam3-80.pth"
# SAM2_TRAINED_CHECKPOINT="./output/epc_ft_sam2/epc-ft_sam2-80.pth"
