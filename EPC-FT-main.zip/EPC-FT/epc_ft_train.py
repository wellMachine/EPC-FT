import os
import argparse
import random
import numpy as np
import py_sod_metrics
import torch
import torch.optim as opt
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import CosineAnnealingLR
from dataset import FullDataset, TestDataset
from model_factory import build_model
from tqdm import tqdm
import time
from datetime import timedelta

parser = argparse.ArgumentParser("Segmentation Training")
parser.add_argument("--model", type=str, default="sam3", choices=["sam3", "sam2"],
                    help="EPC-FT backbone: sam3 or sam2")
parser.add_argument("--checkpoint_path", type=str, default=None,
                    help="path to the backbone pretrained checkpoint")
parser.add_argument("--sam3_path", type=str, default=None,
                    help="legacy alias for SAM3 pretrained checkpoint")
parser.add_argument("--sam2_type", type=str, default="l",
                    help="sam2 backbone type: t/s/b+/l")
parser.add_argument("--sam2_cfg", type=str, default=None,
                    help="optional direct sam2 config name")
parser.add_argument("--train_image_path", type=str, required=True,
                    help="path to the image that used to train the model")
parser.add_argument("--train_mask_path", type=str, required=True,
                    help="path to the mask file for training")
parser.add_argument("--val_image_path", type=str, default=None,
                    help="path to validation image files")
parser.add_argument("--val_mask_path", type=str, default=None,
                    help="path to validation mask files")
parser.add_argument('--save_path', type=str, required=True,
                    help="path to store the checkpoint")
parser.add_argument("--img_size", type=int, default=504,
                    help="training image size")
parser.add_argument("--val_interval", type=int, default=1,
                    help="run validation every N epochs")
parser.add_argument("--epoch", type=int, default=20,
                    help="training epochs")
parser.add_argument("--lr", type=float, default=0.0002, help="learning rate")
parser.add_argument("--batch_size", default=1, type=int)
parser.add_argument("--weight_decay", default=5e-4, type=float)
args = parser.parse_args()


class BestMetricTracker:
    def __init__(self, initial_best=float("-inf")):
        self.best_sm = initial_best
        self.best_epoch = 0

    def update(self, current_sm, epoch):
        if current_sm > self.best_sm:
            self.best_sm = current_sm
            self.best_epoch = epoch
            return True, self.best_sm
        return False, self.best_sm


def build_best_checkpoint_name(model_name):
    backbone = model_name
    return f"epc-ft_{backbone}_best.pth"


def structure_loss(pred, mask):
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)
    wbce = F.binary_cross_entropy_with_logits(pred, mask, reduction='none')
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))
    pred = torch.sigmoid(pred)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    wiou = 1 - (inter + 1) / (union - inter + 1)
    return (wbce + wiou).mean()


def resolve_backbone_checkpoint(args):
    checkpoint_path = args.checkpoint_path or args.sam3_path
    if args.model == "sam3" and checkpoint_path is None:
        raise ValueError("SAM3 requires --checkpoint_path or legacy --sam3_path")
    return checkpoint_path


def validate_val_paths(args):
    if (args.val_image_path is None) ^ (args.val_mask_path is None):
        raise ValueError("Please provide both --val_image_path and --val_mask_path")


def evaluate_smeasure(model, val_image_path, val_mask_path, img_size, device):
    metric = py_sod_metrics.Smeasure()
    test_loader = TestDataset(val_image_path, val_mask_path, img_size)
    model.eval()

    with torch.no_grad():
        for _ in range(test_loader.size):
            image, gt, _ = test_loader.load_data()
            image = image.to(device)
            pred = model(image)
            pred = F.interpolate(pred, size=gt.shape, mode='bilinear', align_corners=False)
            pred = pred.sigmoid().data.cpu().numpy().squeeze()
            pred = (pred - pred.min()) / (pred.max() - pred.min() + 1e-8)
            pred = (pred * 255).astype(np.uint8)
            gt = gt.astype(np.uint8)
            metric.step(pred=pred, gt=gt)

    model.train()
    return float(metric.get_results()["sm"])


def main(args):
    validate_val_paths(args)
    dataset = FullDataset(args.train_image_path, args.train_mask_path, args.img_size, mode='train')
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=8)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(
        model_name=args.model,
        checkpoint_path=resolve_backbone_checkpoint(args),
        img_size=args.img_size,
        sam2_type=args.sam2_type,
        sam2_cfg=args.sam2_cfg,
    )
    model.to(device)
    model.train()
    optim = opt.AdamW([{"params": model.parameters(), "initia_lr": args.lr}], lr=args.lr,
                      weight_decay=args.weight_decay)
    scheduler = CosineAnnealingLR(optim, args.epoch, eta_min=1.0e-7)
    os.makedirs(args.save_path, exist_ok=True)
    best_tracker = BestMetricTracker()
    best_checkpoint_path = os.path.join(args.save_path, build_best_checkpoint_name(args.model))

    start_time = time.time()

    for epoch in range(args.epoch):
        # Progress bar for the current epoch
        pbar = tqdm(dataloader, desc=f'Epoch {epoch + 1}/{args.epoch}', colour='red')
        for i, batch in enumerate(pbar):
            x = batch['image']
            target = batch['label']
            x = x.to(device)
            target = target.to(device)
            optim.zero_grad()
            pred = model(x)
            loss = structure_loss(pred, target)
            loss.backward()
            optim.step()

            # Update progress bar with loss
            pbar.set_postfix({'loss': f"{loss.item():.4f}"})

        # Calculate ETA
        current_time = time.time()
        elapsed_time = current_time - start_time
        avg_time_per_epoch = elapsed_time / (epoch + 1)
        remaining_time = avg_time_per_epoch * (args.epoch - epoch - 1)

        elapsed_str = str(timedelta(seconds=int(elapsed_time)))
        eta_str = str(timedelta(seconds=int(remaining_time)))

        print(f"Epoch [{epoch + 1}/{args.epoch}] Completed. Elapsed: {elapsed_str} | ETA: {eta_str}")

        scheduler.step()
        if args.val_image_path and ((epoch + 1) % args.val_interval == 0 or (epoch + 1) == args.epoch):
            sm = evaluate_smeasure(
                model=model,
                val_image_path=args.val_image_path,
                val_mask_path=args.val_mask_path,
                img_size=args.img_size,
                device=device,
            )
            print(f"Epoch [{epoch + 1}/{args.epoch}] Smeasure: {sm:.4f}")
            improved, best_sm = best_tracker.update(sm, epoch + 1)
            if improved:
                torch.save(model.state_dict(), best_checkpoint_path)
                print(f"[Saving Best]: {best_checkpoint_path} | best_sm={best_sm:.4f}")

        if (epoch + 1) % 20 == 0 or (epoch + 1) == args.epoch:
            backbone = args.model
            snapshot_name = f'epc-ft_{backbone}-{epoch + 1}.pth'
            torch.save(model.state_dict(), os.path.join(args.save_path, snapshot_name))
            print('[Saving Snapshot:]', os.path.join(args.save_path, snapshot_name))


if __name__ == "__main__":
    # seed_torch(1024)
    main(args)
